using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MonoTouch.Foundation;
using MonoTouch.UIKit;
using HangmanCore;
using HangmanCore.Interfaces;
using SQLite;
using HangmanCore.DbModels;

namespace HangmanIOS.Helpers
{
    class DbManager : IDbManager
    {
        public void InitializeConnection()
        {
            try
            {
                // Create our connection
                string folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                var conn = new SQLiteAsyncConnection(System.IO.Path.Combine(folder, "hangman.db"));
                conn.CreateTableAsync<Word>();
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
        }

        public void AddWord(Word word)
        {
            throw new NotImplementedException();
        }

        public void AddWords(List<Word> words)
        {
            throw new NotImplementedException();
        }

        public void AddUser()
        {
            throw new NotImplementedException();
        }

        public void ClearTable(string tableName)
        {
            throw new NotImplementedException();
        }
    }
}